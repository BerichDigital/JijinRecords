(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__698e6b9e._.css",
  "static/chunks/node_modules_ecc0a196._.js"
],
    source: "dynamic"
});
